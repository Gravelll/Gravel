Most code is public domain under [Creative Commons 0](http://creativecommons.org/publicdomain/zero/1.0/)
 	 
Textures and binaries are licensed under [Creative Commons 3](http://creativecommons.org/licenses/by/3.0/) 

Any alternate licenses are noted where appropriate