[Natura](https://minecraft.curseforge.com/projects/natura)
====================================

We work all day and we work all night 	 
The mandrake gives us quite a fright 	 
We munch on berries high and lo 	 
While we search for herbs to grow 	 

Heyo, Redwood trees! Chop them all day long~ 	 
Heyo, Redwood trees! Chop them all day long~ 	

## Setting up a Workspace/Compiling from Source
Note: Git MUST be installed and in the system path to use our scripts.
* Setup: Run [gradle]in the repository root: `gradlew[.bat] [setupDevWorkspace|setupDecompWorkspace] [eclipse|idea]`
* Build: Run [gradle]in the repository root: `gradlew[.bat] build`
* If obscure Gradle issues are found try running `gradlew clean` and `gradlew cleanCache`


[![Discord](https://img.shields.io/discord/102860784329052160.svg?style=for-the-badge)](https://discord.gg/njGrvuh)

If you have queries about any license or the other restrictions, please drop by our IRC channel, #progsmods on irc.esper.net
