package com.progwml6.natura.common;

public class CommonProxy
{
    public void preInit()
    {
        this.registerModels();
    }

    public void init()
    {

    }

    public void postInit()
    {
    }

    protected void registerModels()
    {
    }

    public boolean fancyGraphicsEnabled()
    {
        return false;
    }
}
