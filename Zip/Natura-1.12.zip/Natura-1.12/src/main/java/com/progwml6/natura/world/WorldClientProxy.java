package com.progwml6.natura.world;

import com.progwml6.natura.common.ClientProxy;

public class WorldClientProxy extends ClientProxy
{
    @Override
    public void preInit()
    {
        super.preInit();
    }

    @Override
    public void init()
    {
        super.init();
    }

    @Override
    protected void registerModels()
    {

    }
}
